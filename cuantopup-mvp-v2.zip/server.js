const express=require("express");
const path=require("path");
const Database=require("better-sqlite3");
const crypto=require("crypto");

const app=express();
const PORT=process.env.PORT||3000;
const db=new Database("cuantopup.db");

db.exec(`
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 category TEXT NOT NULL,
 name TEXT NOT NULL,
 nominal TEXT NOT NULL,
 price INTEGER NOT NULL,
 active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_code TEXT UNIQUE NOT NULL,
 category TEXT NOT NULL,
 product TEXT NOT NULL,
 customer_data TEXT NOT NULL,
 price INTEGER NOT NULL,
 status TEXT DEFAULT 'PENDING',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const count=db.prepare("SELECT COUNT(*) c FROM products").get().c;
if(!count){
 const ins=db.prepare("INSERT INTO products(category,name,nominal,price) VALUES(?,?,?,?)");
 const seed=db.transaction(()=>{
   [["game","Mobile Legends","5 Diamonds",5000],["game","Mobile Legends","12 Diamonds",10000],
    ["game","Free Fire","70 Diamonds",10000],["game","PUBG Mobile","60 UC",15000],
    ["game","Valorant","125 VP",15000],["pulsa","Pulsa","Rp5.000",5500],
    ["pulsa","Pulsa","Rp10.000",10500],["pulsa","Pulsa","Rp20.000",20500],
    ["pulsa","Pulsa","Rp50.000",50500]].forEach(x=>ins.run(...x));
 });
 seed();
}

app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

app.get("/api/products",(req,res)=>{
 const category=req.query.category;
 const rows=category?db.prepare("SELECT * FROM products WHERE active=1 AND category=?").all(category)
                    :db.prepare("SELECT * FROM products WHERE active=1").all();
 res.json(rows);
});

app.post("/api/orders",(req,res)=>{
 const {category,product_id,customer_data}=req.body;
 if(!category||!product_id||!customer_data) return res.status(400).json({error:"Data pesanan belum lengkap"});
 const p=db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(product_id);
 if(!p) return res.status(404).json({error:"Produk tidak ditemukan"});
 const code="CT-"+crypto.randomBytes(4).toString("hex").toUpperCase();
 db.prepare(`INSERT INTO orders(order_code,category,product,customer_data,price) VALUES(?,?,?,?,?)`)
   .run(code,category,`${p.name} - ${p.nominal}`,JSON.stringify(customer_data),p.price);
 res.json({order_code:code,price:p.price,status:"PENDING"});
});

app.get("/api/orders/:code",(req,res)=>{
 const o=db.prepare("SELECT order_code,category,product,price,status,created_at FROM orders WHERE order_code=?")
          .get(req.params.code.toUpperCase());
 if(!o)return res.status(404).json({error:"Transaksi tidak ditemukan"});
 res.json(o);
});

app.listen(PORT,()=>console.log(`CuanTopup berjalan di http://localhost:${PORT}`));
