# CuanTopup MVP V2

## Menjalankan
1. Install Node.js 20+.
2. Buka terminal di folder ini.
3. Jalankan `npm install`.
4. Jalankan `npm start`.
5. Buka `http://localhost:3000`.

Database SQLite (`cuantopup.db`) dibuat otomatis.

## Status
Ini sudah punya backend + database + API order. Namun BELUM siap menerima pembayaran nyata atau mengirim game/pulsa nyata.

Untuk launching produksi masih perlu:
- hosting/domain + HTTPS
- payment gateway dan webhook
- supplier/API top-up yang resmi
- konfigurasi harga/margin
- halaman admin
- keamanan, logging, rate limit, dan backup database
